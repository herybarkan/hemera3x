/*
 Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'et', {
	embeddingInProgress: 'Püütakse asetatud URLi sisu lisada...',
	embeddingFailed: 'Selle URLi sisu ei saa automaatselt dokumenti lisada.'
} );
