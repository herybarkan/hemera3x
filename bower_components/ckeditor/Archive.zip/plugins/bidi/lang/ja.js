/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'bidi', 'ja', {
	ltr: 'テキストの向き : 左から右へ',
	rtl: 'テキストの向き : 右から左へ'
} );
