/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'bidi', 'si', {
	ltr: 'වගන්ති දිශාව වමේ සිට දකුණට',
	rtl: 'වගන්ති දිශාව  දකුණේ සිට වමට'
} );
