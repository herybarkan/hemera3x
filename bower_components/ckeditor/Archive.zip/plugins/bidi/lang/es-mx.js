/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'bidi', 'es-mx', {
	ltr: 'Dirección del texto de izquierda a derecha',
	rtl: 'Dirección del texto de derecha a izquierda'
} );
