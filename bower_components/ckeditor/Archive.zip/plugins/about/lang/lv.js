/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'lv', {
	copy: 'Kopēšanas tiesības &copy; $1. Visas tiesības rezervētas.',
	dlgTitle: 'Par CKEditor 4',
	moreInfo: 'Informācijai par licenzēšanu apmeklējiet mūsu mājas lapu:'
} );
